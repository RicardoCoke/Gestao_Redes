package grsd_p01_javarmi;

public class GRSD_P01_JavaRMI {

    public static void main(String[] args) {
    }
}
